package com.company;

public enum Genero {
    ACCION,
    COMEDIA,
    FANTASIA,
    TERROR
}
