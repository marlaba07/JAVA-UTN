class Yate implements VehiculoMaritimo {
    private static final double PRECIO_YATE = 100;

    @Override
    public double calcularPrecio() {
        return PRECIO_YATE;
    }
}

