public enum ModoCambios {
    MANUAL, AUTOMATICO, SEMI_AUTOMATICO;
}

