interface VehiculoMaritimo {
    double calcularPrecio();


    default String hacerAlgo(int i){
        return "aksals"+ i ;
    }


}
